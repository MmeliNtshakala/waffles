package za.co.wethinkcode.botworld.model;

public enum Heading
{
    North, South, West, East
}
